
/*
  SMART WATER PURIFICATION SYSTEM
  Version 2: Treatment Control Simulation

  Board: ESP32-S3
  Simulator: Wokwi

  Four potentiometers simulate raw-water sensors.
  Sediment filtration and RO are modeled in software.
  This is not a validated physical water-treatment model.
*/

#include <Arduino.h>

// ---------- INPUT PINS ----------
const int PH_PIN        = 1;
const int TURBIDITY_PIN = 2;
const int TDS_PIN       = 4;
const int TEMP_PIN      = 5;

// ---------- LED PINS ----------
const int GREEN_LED  = 18;
const int RED_LED    = 19;
const int YELLOW_LED = 6;

// ---------- DEMO LIMITS ----------
const float PH_MIN = 6.5;
const float PH_MAX = 8.5;
const float TURBIDITY_MAX = 5.0;
const float TDS_MAX = 500.0;

// ---------- STAGE DURATIONS ----------
const unsigned long SEDIMENT_TIME_MS = 4000;
const unsigned long RO_TIME_MS = 6000;
const unsigned long PRINT_INTERVAL_MS = 2000;

// ---------- ILLUSTRATIVE MODEL FACTORS ----------
// Sediment stage reduces modeled turbidity to 20%.
// RO stage further reduces turbidity to 50% of that value.
// RO stage reduces modeled TDS to 30% of its initial value.
// pH and temperature are unchanged in this model.
const float SEDIMENT_TURBIDITY_FACTOR = 0.20;
const float RO_TURBIDITY_FACTOR = 0.50;
const float RO_TDS_FACTOR = 0.30;

// ---------- SENSOR READINGS ----------
float rawPH = 0;
float rawTurbidity = 0;
float rawTDS = 0;
float rawTemperature = 0;

// ---------- MODELED OUTPUT READINGS ----------
float outputPH = 0;
float outputTurbidity = 0;
float outputTDS = 0;
float outputTemperature = 0;

// ---------- CONTROLLER STATES ----------
enum SystemState {
  IDLE,
  SEDIMENT_FILTRATION,
  RO_TREATMENT,
  OUTPUT_ASSESSMENT
};

SystemState state = IDLE;

unsigned long stageStartTime = 0;
unsigned long lastPrintTime = 0;

bool rawPass = false;
bool outputPass = false;

// ---------- SENSOR READING ----------
void readSensors() {
  rawPH = analogRead(PH_PIN) * 14.0 / 4095.0;

  rawTurbidity =
    analogRead(TURBIDITY_PIN) * 1000.0 / 4095.0;

  rawTDS =
    analogRead(TDS_PIN) * 2000.0 / 4095.0;

  rawTemperature =
    analogRead(TEMP_PIN) * 60.0 / 4095.0;
}

// ---------- QUALITY CHECKS ----------
bool passesQualityChecks(float ph, float turbidity, float tds) {
  return ph >= PH_MIN &&
         ph <= PH_MAX &&
         turbidity <= TURBIDITY_MAX &&
         tds <= TDS_MAX;
}

// ---------- START TREATMENT ----------
void startTreatment() {
  state = SEDIMENT_FILTRATION;
  stageStartTime = millis();

  Serial.println();
  Serial.println("TREATMENT STARTED");
  Serial.println("Simulated pump: ON");
  Serial.println("Stage 1: Sediment filtration");
}

// ---------- MODEL TREATMENT OUTPUT ----------
void calculateOutputReadings() {
  outputPH = rawPH;

  outputTurbidity =
    rawTurbidity *
    SEDIMENT_TURBIDITY_FACTOR *
    RO_TURBIDITY_FACTOR;

  outputTDS = rawTDS * RO_TDS_FACTOR;

  outputTemperature = rawTemperature;
}

// ---------- CONTROLLER ----------
void updateController() {
  rawPass = passesQualityChecks(
    rawPH, rawTurbidity, rawTDS
  );

  // When raw water passes the demo checks,
  // no treatment is requested.
  if (rawPass && state != SEDIMENT_FILTRATION &&
      state != RO_TREATMENT) {

    state = IDLE;

    outputPH = rawPH;
    outputTurbidity = rawTurbidity;
    outputTDS = rawTDS;
    outputTemperature = rawTemperature;

    outputPass = passesQualityChecks(
      outputPH, outputTurbidity, outputTDS
    );

    return;
  }

  // Automatically start a treatment cycle if raw water fails.
  if (state == IDLE && !rawPass) {
    startTreatment();
    return;
  }

  unsigned long elapsed = millis() - stageStartTime;

  // Stage 1: Sediment filtration simulation
  if (state == SEDIMENT_FILTRATION &&
      elapsed >= SEDIMENT_TIME_MS) {

    state = RO_TREATMENT;
    stageStartTime = millis();

    Serial.println("Stage 1 complete.");
    Serial.println("Stage 2: RO treatment simulation");
  }

  // Stage 2: RO simulation
  else if (state == RO_TREATMENT &&
           elapsed >= RO_TIME_MS) {

    calculateOutputReadings();

    state = OUTPUT_ASSESSMENT;

    outputPass = passesQualityChecks(
      outputPH, outputTurbidity, outputTDS
    );

    Serial.println("RO stage complete.");
    Serial.println("Simulated pump: OFF");
    Serial.println("Checking modeled output quality...");

    Serial.print("Output result: ");
    Serial.println(outputPass ? "PASS" : "FAIL");
  }

  // OUTPUT_ASSESSMENT remains active until the raw input
  // returns to passing values, allowing a new cycle later.
}

// ---------- LED CONTROL ----------
void updateLEDs() {
  bool treatmentActive =
    (state == SEDIMENT_FILTRATION ||
     state == RO_TREATMENT);

  bool outputPassed =
    (state == IDLE && rawPass) ||
    (state == OUTPUT_ASSESSMENT && outputPass);

  bool outputFailed =
    (state == OUTPUT_ASSESSMENT && !outputPass);

  digitalWrite(GREEN_LED, outputPassed ? HIGH : LOW);
  digitalWrite(YELLOW_LED, treatmentActive ? HIGH : LOW);
  digitalWrite(RED_LED, outputFailed ? HIGH : LOW);
}

// ---------- SERIAL MONITOR ----------
void printStatus() {
  Serial.println();
  Serial.println("========== WATER STATUS ==========");

  Serial.print("Raw pH: ");
  Serial.println(rawPH, 2);

  Serial.print("Raw turbidity: ");
  Serial.print(rawTurbidity, 2);
  Serial.println(" NTU (simulated)");

  Serial.print("Raw TDS: ");
  Serial.print(rawTDS, 2);
  Serial.println(" ppm (simulated)");

  Serial.print("Temperature: ");
  Serial.print(rawTemperature, 2);
  Serial.println(" C (simulated)");

  Serial.print("Controller state: ");

  switch (state) {
    case IDLE:
      Serial.println("IDLE");
      break;

    case SEDIMENT_FILTRATION:
      Serial.println("SEDIMENT FILTRATION");
      break;

    case RO_TREATMENT:
      Serial.println("RO TREATMENT");
      break;

    case OUTPUT_ASSESSMENT:
      Serial.println("OUTPUT ASSESSMENT");
      break;
  }

  if (state == IDLE || state == OUTPUT_ASSESSMENT) {
    Serial.print("Output pH: ");
    Serial.println(outputPH, 2);

    Serial.print("Output turbidity: ");
    Serial.print(outputTurbidity, 2);
    Serial.println(" NTU (modeled)");

    Serial.print("Output TDS: ");
    Serial.print(outputTDS, 2);
    Serial.println(" ppm (modeled)");

    Serial.print("Output temperature: ");
    Serial.print(outputTemperature, 2);
    Serial.println(" C (modeled)");

    Serial.print("Output checks: ");
    Serial.println(outputPass ? "PASS" : "FAIL");
  }

  Serial.println("==================================");
}

// ---------- SETUP ----------
void setup() {
  Serial.begin(115200);
  delay(1000);

  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(YELLOW_LED, OUTPUT);

  analogReadResolution(12);

  digitalWrite(GREEN_LED, LOW);
  digitalWrite(RED_LED, LOW);
  digitalWrite(YELLOW_LED, LOW);

  Serial.println();
  Serial.println("SMART WATER SYSTEM - VERSION 2");
  Serial.println("Simulation started");
}

// ---------- MAIN LOOP ----------
void loop() {
  readSensors();
  updateController();
  updateLEDs();

  if (millis() - lastPrintTime >= PRINT_INTERVAL_MS) {
    lastPrintTime = millis();
    printStatus();
  }

  delay(10);
}
